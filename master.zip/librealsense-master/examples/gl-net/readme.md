# rs-gl-net Sample

## Overview

This sample demonstrates how to connect to remote rs-server over the network and to utilize the GPU for processing of depth frames received from remote camera.

All other information relating utilizing of the GPU see in readme.md of rs-gl sample
